from datetime import datetime
import os
import pytest
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait


class web_driver:
    try:
        chrome_options = Options()
        chrome_options.add_experimental_option("detach", True)
        d = webdriver.Chrome(options=chrome_options)
        one_second = 1
        two_second = 2
        three_second = 3
        screenshots_path = f"{Path(__file__).parent.parent}\\Reports\\Screenshots"
    except Exception as ex:
        print("init constructor in base class has an err: ", ex)

    def implicit_wait(self, seconds, driver):
        driver.implicitly_wait(seconds)

    """set Explicit wait function to be used by all the web elements where ever it is needed"""

    def explicit_wait(self, seconds, element, driver):
        wait = WebDriverWait(driver, seconds)
        ele = wait.until(expected_conditions.element_to_be_clickable(element))

    @staticmethod
    @pytest.fixture(scope="function")
    def setup_method(self):
        try:
            print("\nsetup start")
            print("setup function exe")
            d = webdriver.d
            d.maximize_window()
            d.set_page_load_timeout(50)
            d.set_script_timeout(30)
            d.implicitly_wait(30)
            print("\nsetup end")
        except Exception as ex:
            print("\nException in Test_Deployment_Manager_Test_Cases/setup_method: ", ex)
