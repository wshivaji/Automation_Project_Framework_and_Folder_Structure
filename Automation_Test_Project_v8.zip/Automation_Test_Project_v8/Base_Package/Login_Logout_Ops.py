import time

from Base_Package.Web_Driver import web_driver
from Base_Package.Web_Logger import web_logger
from pathlib import Path
import configparser
from selenium.webdriver.common.by import By


class login(web_driver, web_logger):

    def __init__(self):
        self.file_path = f"{Path(__file__).parent.parent}\\All_Test_Data\\0_Login_Logout_Data\\Data_From_INI\\login_logout.ini"
        print(f"INI Data File Path: {self.file_path}")
        self.config = configparser.RawConfigParser()
        self.config.read(self.file_path)
        self.local_url = self.config.get("login_urls", "local_login_url")
        self.cloud_url = self.config.get("login_urls", "cloud_login_url")
        print(f"local url: {self.local_url}")
        print(f"cloud url: {self.cloud_url}")
        self.d = web_driver.d
        self.logger = web_logger.logger_obj()

    def login_to_localhost_if_not_done(self):
        try:
            current_url = self.d.current_url
            if current_url is None or current_url != self.local_url:
                self.logger.info("url is not open")
                self.d.get(self.local_url)
                self.logger.info("opening localhost portal login")
                self.logger.info("logging in to localhost")
                username_textbox = self.d.find_element(By.XPATH, self.config.get("login_page_locators", "username_textbox_by_xpath"))
                password_textbox = self.d.find_element(By.XPATH, self.config.get("login_page_locators", "password_textbox_by_xpath"))
                login_btn = self.d.find_element(By.XPATH, self.config.get("login_page_locators", "login_link_by_xpath"))
                username_textbox.send_keys(self.config.get("user_info", "username"))
                password_textbox.send_keys(self.config.get("user_info", "password"))
                login_btn.click()

            else:
                self.logger.info("localhost already logged in")
                pass

        except Exception as ex:
            self.logger.info(f"exception: {ex.args}")
            print(f"{ex.args}")

    def login_to_cloud_if_not_done(self):
        try:
            current_url = self.d.current_url
            if current_url is None or current_url != self.cloud_url:
                self.logger.info("url is not open")
                self.d.get(self.cloud_url)
                self.d.maximize_window()
                self.logger.info("opening localhost portal login")
                self.logger.info("logging in to core")
                self.implicit_wait(web_driver.one_second, self.d)
                print(f"portal login page title: {self.d.title}")
                username_textbox = self.d.find_element(By.XPATH, self.config.get("login_page_locators", "username_textbox_by_xpath"))
                web_driver.explicit_wait(self, web_driver.two_second, username_textbox, self.d)
                password_textbox = self.d.find_element(By.XPATH, self.config.get("login_page_locators", "password_textbox_by_xpath"))
                login_btn = self.d.find_element(By.XPATH, self.config.get("login_page_locators", "login_link_by_xpath"))
                self.implicit_wait(web_driver.one_second, self.d)
                username_textbox.send_keys(self.config.get("user_info", "username"))
                self.implicit_wait(web_driver.one_second, self.d)
                password_textbox.send_keys(self.config.get("user_info", "password"))
                self.implicit_wait(web_driver.one_second, self.d)
                login_btn.click()
                self.implicit_wait(web_driver.one_second, self.d)
                logout_btn = self.d.find_element(By.XPATH, self.config.get("logout_locators", "logout_btn_by_xpath"))
                web_driver.explicit_wait(self, web_driver.two_second, logout_btn, self.d)
                time.sleep(web_driver.two_second)
                if logout_btn.is_displayed():
                    self.logger.info("login success..")
                else:
                    self.logger.info("login unsuccessful.. please check code.")
                    self.d.save_screenshot(f"{web_driver.screenshots_path}\\login_failed.png")
            else:
                self.logger.info("localhost already logged in")
                pass

        except Exception as ex:
            self.logger.info(f"exception: {ex.args}")
            self.d.save_screenshot(f"{web_driver.screenshots_path}\\login_exception.png")
            print(f"{ex.args}")

    def logout_from_core(self):
        try:
            time.sleep(web_driver.one_second)
            current_url = self.d.current_url
            if current_url == self.config.get("login_urls", "cloud_login_url") and self.config.get("execution_settings", "logout_on_each_test") == "True":
                self.logger.info(f"current url: {current_url}")
                self.logger.info(f"actual url: {self.config.get('login_urls', 'cloud_login_url')}")
                cloud_menu_btn = self.d.find_element(By.XPATH, self.config.get("logout_locators", "cloud_or_local_menu_by_xpath"))
                web_driver.explicit_wait(self, web_driver.two_second, cloud_menu_btn, self.d)
                cloud_menu_btn.click()
                close_all_submenu_list = self.d.find_elements(By.XPATH, self.config.get("logout_locators", "close_all_panels_menu_by_xpath"))
                self.logger.info(f"close all btn object count: {len(close_all_submenu_list)}")
                if len(close_all_submenu_list) > 0:
                    close_all_submenu_list[0].click()
                else:
                    logout_btn = self.d.find_element(By.XPATH, self.config.get("logout_locators", "logout_btn_by_xpath"))
                    web_driver.explicit_wait(self, web_driver.two_second, logout_btn, self.d)
                    logout_btn.click()

            elif self.config.get("execution_settings", "logout_on_each_test") == "False":
                print("logout skipped due to setting is False")

            else:
                print(f"wrong url detected: {current_url}")
                self.logger.info(f"wrong url detected: {current_url}")
                self.d.save_screenshot(f"{web_driver.screenshots_path}\\logout_failed.png")
        except Exception as ex:
            self.logger.info(f"logout exception: {ex.args}")
            self.d.save_screenshot(f"{web_driver.screenshots_path}\\logout_exception.png")
            print(ex.args)


class logout(web_driver, web_logger):
    def __init__(self):
        self.file_path = f"{Path(__file__).parent.parent}\\All_Test_Data\\0_Login_Logout_Data\\Data_From_INI\\login_logout.ini"
        print(f"INI Data File Path: {self.file_path}")
        self.config = configparser.RawConfigParser()
        self.config.read(self.file_path)
        self.local_url = self.config.get("login_urls", "local_login_url")
        self.cloud_url = self.config.get("login_urls", "cloud_login_url")
        # print(f"local url: {self.local_url}")
        # print(f"cloud url: {self.cloud_url}")
        self.d = web_driver.d
        self.logger = web_logger.logger_obj()

    def logout_from_core(self):
        try:
            time.sleep(web_driver.one_second)
            current_url = self.d.current_url
            if current_url == self.config.get("login_urls", "cloud_login_url"):
                self.logger.info(f"current url: {current_url}")
                self.logger.info(f"actual url: {self.config.get('login_urls', 'cloud_login_url')}")
                cloud_menu_btn = self.d.find_element(By.XPATH, self.config.get("logout_locators", "cloud_or_local_menu_by_xpath"))
                web_driver.explicit_wait(self, web_driver.two_second, cloud_menu_btn, self.d)
                cloud_menu_btn.click()
                close_all_submenu_list = self.d.find_elements(By.XPATH, self.config.get("logout_locators", "close_all_panels_menu_by_xpath"))
                self.logger.info(f"close all btn object count: {len(close_all_submenu_list)}")
                if len(close_all_submenu_list) > 0:
                    close_all_submenu_list[0].click()
                else:
                    logout_btn = self.d.find_element(By.XPATH, self.config.get("logout_locators", "logout_btn_by_xpath"))
                    web_driver.explicit_wait(self, web_driver.two_second, logout_btn, self.d)
                    logout_btn.click()

            else:
                print(f"wrong url detected: {current_url}")
                self.logger.info(f"wrong url detected: {current_url}")
                self.d.save_screenshot(f"{web_driver.screenshots_path}\\logout_failed.png")
        except Exception as ex:
            self.logger.info(f"logout exception: {ex.args}")
            self.d.save_screenshot(f"{web_driver.screenshots_path}\\logout_exception.png")
            print(ex.args)


# login().login_to_localhost_if_not_done()
# login().login_to_cloud_if_not_done()
# login().logout_from_core()
