import time

from Base_Package.Web_Driver import web_driver
from Base_Package.Web_Logger import web_logger
from Base_Package.Login_Logout_Ops import login, logout
import pytest



class Test_User_Roles_Test_Cases(web_driver, web_logger):
    d = web_driver.d
    logger = web_logger.logger_obj()

    @pytest.mark.p1
    def test_user_role_01(self):
        try:
            login().login_to_cloud_if_not_done()
            time.sleep(web_driver.one_second)
            web_driver.implicit_wait(self, web_driver.one_second, self.d)

            logout().logout_from_core()
        except Exception as ex:
            self.logger.info(f"test_PL_01 Exception: {ex.args}")
            self.d.save_screenshot(f"{web_driver.screenshots_path}\\test_PL_01_exception.png")
            print(ex.args)

