import time

from Base_Package.Web_Driver import web_driver
from Base_Package.Web_Logger import web_logger
from pathlib import Path
import configparser
from selenium.webdriver.common.by import By
from Base_Package.Login_Logout_Ops import logout, login

class user_roles_module_pom(web_driver, web_logger):
    d = web_driver.d
    logger = web_logger.logger_obj()

    def test_one(self):
        try:
            login().login_to_cloud_if_not_done()
            status = []
            cloud_menu= self.d.find_element(By.XPATH, )
            web_driver.explicit_wait(self, web_driver.one_second, cloud_menu, self.d)


            self.logger.info(f"status: {status}")
            if False in status:
                return False
            else:
                self.d.save_screenshot(f"{web_driver.screenshots_path}\\test_user_role_01_failed.png")
                return True
            logout().logout_from_core()
        except Exception as ex:
            self.d.save_screenshot(f"{web_driver.screenshots_path}\\test_user_role_01_exception.png")
            print(ex.args)



